<?php
// include class file
require_once 'mysql_class.php';
// connect to MySQL
$db=&new MySQL(array('host'=>'localhost','user'=>'root','password'=>'sawstudio','database'=>'chat'));
// get user & message
$user=$_POST['user'];
$message=$_POST['message'];
// insert new message into database table
$db->query("INSERT INTO messages SET user='$user',message='$message'");
// get ID from last inserted message
$id=$db->getInsertID();
// delete messages when ID > 1000
if($id>1000){
	$db->query("DELETE FROM messages WHERE id <($id-10)");
}
// retrieve last 20 messages
$db->query("SELECT user,message FROM messages WHERE id <=$id ORDER BY id DESC LIMIT 20");
// send messages to the client
while($row=$db->fetchRow()){
	echo '<'.$row['user'].'>'.$row['message'].'|';
}
?>