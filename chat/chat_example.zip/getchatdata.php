<?php
// include class file
require_once 'mysql_class.php';
// connect to MySQL
$db=&new MySQL(array('host'=>'localhost','user'=>'root','password'=>'sawstudio','database'=>'chat'));
// retrieve last 20 messages
$db->query("SELECT user,message FROM messages ORDER BY id DESC LIMIT 20");
// send messages to the client
while($row=$db->fetchRow()){
	echo '<'.$row['user'].'>'.$row['message'].'|';
}
?>
