<?php
include_once(dirname(__FILE__).'/../../admin/config.php');
?>
