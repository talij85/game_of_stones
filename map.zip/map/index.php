<?php
header("Location: http://".$_SERVER['SERVER_NAME']);
?>